// --- 1. CONFIG ---
const HOUR_LABELS = [
    "Practical Hour 1 & 2",
    "Theory 1",
    "Theory 2",
    "Theory 3",
    "Practical Hour 3"
];

// --- 2. INIT & CLOCK ---
function updateClock() {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    let hours = now.getHours();
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    const strTime = `${day}/${month}/${year} - ${hours}:${minutes} ${ampm}`;
    document.getElementById('dateTimeDisplay').innerText = strTime;
}
setInterval(updateClock, 1000);
updateClock(); 

// Set Default Dates
document.getElementById('attendanceDate').valueAsDate = new Date();
document.getElementById('repDate').valueAsDate = new Date();
document.getElementById('repYearInput').value = new Date().getFullYear();

// --- 3. DROPDOWN HELPERS ---
function onCourseChange(cId, yId, sId) {
    updateYears(cId, yId);
    if(sId) updateSemesters(cId, sId);
}

function updateYears(cId, yId) {
    const course = document.getElementById(cId).value;
    const yearSelect = document.getElementById(yId);
    yearSelect.innerHTML = '<option value="">-- Year --</option>';
    let years = (course === 'BPES') ? 3 : 2;
    for(let i=1; i<=years; i++){
        yearSelect.add(new Option(i + " Year", i));
    }
}

function updateSemesters(cId, sId) {
    const course = document.getElementById(cId).value;
    const semSelect = document.getElementById(sId);
    semSelect.innerHTML = '<option value="">-- Sem --</option>';
    if(!course) return;
    let totalSems = (course === 'BPES') ? 6 : 4;
    for(let i=1; i<=totalSems; i++) {
        semSelect.add(new Option("Semester " + i, i));
    }
}

// --- 4. PAGE NAVIGATION ---
let selectedHour = null;

function goToPage2() {
    const c = document.getElementById('courseSelect').value;
    const y = document.getElementById('yearSelect').value;
    const s = document.getElementById('semSelect').value;
    if(!c || !y || !s) { alert("Select Course, Year & Sem"); return; }

    document.getElementById('page1').classList.remove('active-page');
    document.getElementById('page2').classList.add('active-page');
    document.getElementById('classTitle').innerText = `${c} - Year ${y} (Sem ${s})`;
    
    selectedHour = null;
    document.querySelectorAll('.hour-option').forEach(el => el.classList.remove('selected'));
    document.getElementById('studentListContainer').innerHTML = '<p style="text-align:center; color:#666; padding:20px;">Select an hour to load student list.</p>';
}

function goToPage1() {
    document.getElementById('page2').classList.remove('active-page');
    document.getElementById('page1').classList.add('active-page');
}

// --- 5. ATTENDANCE LOGIC ---
function selectHour(el, hourName) {
    document.querySelectorAll('.hour-option').forEach(d => d.classList.remove('selected'));
    el.classList.add('selected');
    selectedHour = hourName;
    checkExistingRecord();
}

function checkExistingRecord() {
    if(!selectedHour) return;

    const c = document.getElementById('courseSelect').value;
    const y = document.getElementById('yearSelect').value;
    const s = document.getElementById('semSelect').value;
    const d = document.getElementById('attendanceDate').value;
    
    const recordKey = `REC_${c}_${y}_${s}_${d}_${selectedHour}`;
    const savedData = JSON.parse(localStorage.getItem(recordKey));
    const studentKey = `STUD_${c}_${y}`;
    const students = JSON.parse(localStorage.getItem(studentKey)) || [];

    renderStudentList(students, savedData);
}

function renderStudentList(students, savedData) {
    const container = document.getElementById('studentListContainer');
    container.innerHTML = '';
    if(students.length === 0) {
        container.innerHTML = '<p style="color:red; text-align:center;">No students in database for this Year.</p>';
        return;
    }
    students.forEach((stu, idx) => {
        let status = 'Present'; 
        if(savedData) {
            const record = savedData.find(r => r.roll === stu.roll);
            if(record) status = record.status;
        }
        const pClass = (status === 'Present') ? 'active-p' : '';
        const aClass = (status === 'Absent') ? 'active-a' : '';

        const html = `
        <div class="student-row">
            <div class="student-info">
                <h4>${stu.name}</h4>
                <span>${stu.roll}</span>
            </div>
            <div class="status-toggle">
                <div class="status-btn ${pClass}" onclick="setStatus(${idx}, 'Present')" id="btn_p_${idx}">P</div>
                <div class="status-btn ${aClass}" onclick="setStatus(${idx}, 'Absent')" id="btn_a_${idx}">A</div>
                <input type="hidden" id="status_${idx}" value="${status}">
                <input type="hidden" id="roll_${idx}" value="${stu.roll}">
                <input type="hidden" id="name_${idx}" value="${stu.name}">
            </div>
        </div>`;
        container.innerHTML += html;
    });
}

function setStatus(idx, val) {
    document.getElementById(`status_${idx}`).value = val;
    if(val === 'Present') {
        document.getElementById(`btn_p_${idx}`).classList.add('active-p');
        document.getElementById(`btn_a_${idx}`).classList.remove('active-a');
    } else {
        document.getElementById(`btn_p_${idx}`).classList.remove('active-p');
        document.getElementById(`btn_a_${idx}`).classList.add('active-a');
    }
}

function submitAttendance() {
    if(!selectedHour) { alert("Select Hour"); return; }
    const c = document.getElementById('courseSelect').value;
    const y = document.getElementById('yearSelect').value;
    const s = document.getElementById('semSelect').value;
    const d = document.getElementById('attendanceDate').value;
    const rows = document.querySelectorAll('.student-row');
    if(rows.length === 0) return;

    let recordData = [];
    rows.forEach((row, i) => {
        recordData.push({
            roll: document.getElementById(`roll_${i}`).value,
            name: document.getElementById(`name_${i}`).value,
            status: document.getElementById(`status_${i}`).value
        });
    });

    const recordKey = `REC_${c}_${y}_${s}_${d}_${selectedHour}`;
    localStorage.setItem(recordKey, JSON.stringify(recordData));
    alert("Saved successfully!");
}

// --- 6. REPORT LOGIC ---
function openReportModal() { document.getElementById('reportModal').style.display = 'block'; }
function closeReportModal() { document.getElementById('reportModal').style.display = 'none'; document.getElementById('printableReport').style.display = 'none'; }

function downloadExcel() {
    var table = document.getElementById("repBody").parentElement; 
    var details = document.getElementById("repHeaderDetails").innerText;
    var html = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
    <head></head>
    <body><h3>Annamalai University - Dept of Physical Education</h3><p>${details}</p>${table.outerHTML}</body></html>`;
    var blob = new Blob([html], { type: "application/vnd.ms-excel" });
    var link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "Attendance_Report.xls";
    link.click();
}

function generateDayReport() {
    const c = document.getElementById('repCourse').value;
    const y = document.getElementById('repYear').value;
    const s = document.getElementById('repSem').value;
    const d = document.getElementById('repDate').value;
    if(!c || !y || !s || !d) { alert("Fill required fields"); return; }
    const studentKey = `STUD_${c}_${y}`;
    const students = JSON.parse(localStorage.getItem(studentKey));
    if(!students || students.length === 0) { alert("No students found in database."); return; }

    let headers = ["Roll", "Name", ...HOUR_LABELS, "Day %"];
    let rows = students.map(stu => {
        let rowData = [stu.roll, stu.name];
        let presentCount = 0;
        let totalMarked = 0;
        HOUR_LABELS.forEach(hLabel => {
            const key = `REC_${c}_${y}_${s}_${d}_${hLabel}`;
            const sessionData = JSON.parse(localStorage.getItem(key)) || [];
            const record = sessionData.find(r => r.roll === stu.roll);
            let cellVal = "-";
            if(record) {
                cellVal = (record.status === 'Present') ? 'P' : 'A';
                totalMarked++;
                if(record.status === 'Present') presentCount++;
            }
            rowData.push(cellVal);
        });
        let percent = (totalMarked > 0) ? Math.round((presentCount / totalMarked) * 100) + "%" : "-";
        rowData.push(percent);
        return rowData;
    });
    showReportTable(`DAILY REPORT<br>Class: ${c} Year ${y} (Sem ${s}) | Date: ${d}`, headers, rows);
}

function generatePeriodReport(type) {
    const c = document.getElementById('repCourse').value;
    const y = document.getElementById('repYear').value;
    const s = document.getElementById('repSem').value;
    let filterStr = "";
    let title = "";
    if (type === 'monthly') {
        const mInput = document.getElementById('repMonth').value; 
        if(!mInput || !c || !y || !s) { alert("Select Month, Course, Year, Sem"); return; }
        filterStr = mInput; 
        title = `MONTHLY REPORT (${mInput})`;
    } else {
        const yInput = document.getElementById('repYearInput').value; 
        if(!yInput || !c || !y || !s) { alert("Select Year, Course, Year, Sem"); return; }
        filterStr = yInput;
        title = `YEARLY REPORT (${yInput})`;
    }
    const students = JSON.parse(localStorage.getItem(`STUD_${c}_${y}`)) || [];
    if(students.length === 0) { alert("No students found."); return; }
    let stats = {}; 
    students.forEach(stu => stats[stu.roll] = { name: stu.name, total: 0, present: 0 });
    const prefix = `REC_${c}_${y}_${s}_`;
    let foundRecords = false;
    for(let i=0; i<localStorage.length; i++) {
        const key = localStorage.key(i);
        if(key.startsWith(prefix)) {
            const parts = key.split('_');
            const datePart = parts[4]; 
            if(datePart.startsWith(filterStr)) {
                foundRecords = true;
                const sessionData = JSON.parse(localStorage.getItem(key));
                sessionData.forEach(rec => {
                    if(stats[rec.roll]) {
                        stats[rec.roll].total++;
                        if(rec.status === 'Present') stats[rec.roll].present++;
                    }
                });
            }
        }
    }
    if(!foundRecords) { alert(`No records found for ${title}`); return; }
    let headers = ["Roll", "Name", "Total Sessions", "Attended", "Percentage"];
    let rows = [];
    Object.keys(stats).sort().forEach(roll => {
        const s = stats[roll];
        const pct = s.total > 0 ? Math.round((s.present / s.total) * 100) + "%" : "0%";
        rows.push([roll, s.name, s.total, s.present, pct]);
    });
    showReportTable(`${title}<br>Class: ${c} Year ${y} (Sem ${s})`, headers, rows);
}

function generateIndividualReport() {
    const roll = document.getElementById('repRoll').value.trim();
    const c = document.getElementById('repCourse').value;
    const y = document.getElementById('repYear').value;
    const s = document.getElementById('repSem').value;
    if(!roll || !c || !y || !s) { alert("Please Select Course, Year, Semester and Enter Roll No."); return; }
    const prefix = `REC_${c}_${y}_${s}_`; 
    let totalSessions = 0, presentCount = 0;
    let daysAttended = {}; 
    let studentName = "";
    for(let i=0; i<localStorage.length; i++) {
        const key = localStorage.key(i);
        if(key.startsWith(prefix)) {
            const sessionData = JSON.parse(localStorage.getItem(key));
            const studentRecord = sessionData.find(r => r.roll === roll);
            if(studentRecord) {
                if(!studentName) studentName = studentRecord.name;
                totalSessions++;
                if(studentRecord.status === 'Present') presentCount++;
                const parts = key.split('_');
                const date = parts[4]; 
                const hour = parts[5];
                if(!daysAttended[date]) daysAttended[date] = [];
                daysAttended[date].push({ hour: hour, status: studentRecord.status });
            }
        }
    }
    if(totalSessions === 0) { alert("No attendance records found for Roll No: " + roll); return; }
    const percentage = Math.round((presentCount / totalSessions) * 100);
    let tableRows = [];
    tableRows.push(["TOTAL SUMMARY", `Sessions: ${totalSessions}`, `Present: ${presentCount}`, `Percentage: ${percentage}%`]);
    tableRows.push(["-", "-", "-", "-"]);
    Object.keys(daysAttended).sort().forEach(date => {
        daysAttended[date].forEach(rec => {
            tableRows.push([date, rec.hour, rec.status, "-"]);
        });
    });
    showReportTable(`INDIVIDUAL REPORT<br>Name: ${studentName} | Roll: ${roll}<br>Overall: ${percentage}%`, ["Date", "Hour", "Status", "Note"], tableRows);
}

function showReportTable(title, headers, rows) {
    document.getElementById('printableReport').style.display = 'block';
    document.getElementById('repHeaderDetails').innerHTML = title;
    let theadHTML = '<tr style="background:#eee;">';
    headers.forEach(h => theadHTML += `<th>${h}</th>`);
    theadHTML += '</tr>';
    document.getElementById('repTableHead').innerHTML = theadHTML;
    let tbodyHTML = '';
    rows.forEach(r => {
        tbodyHTML += '<tr>';
        r.forEach((cell, idx) => {
            let color = '';
            if(cell === 'A' || cell === 'Absent') color = 'color:red; font-weight:bold;';
            if(cell === 'P' || cell === 'Present') color = 'color:green; font-weight:bold;';
            if(typeof cell === 'string' && cell.includes('%')) color = 'font-weight:bold; color:#004085;';
            tbodyHTML += `<td style="${color}">${cell}</td>`;
        });
        tbodyHTML += '</tr>';
    });
    document.getElementById('repBody').innerHTML = tbodyHTML;
}

// --- 7. STUDENT MANAGEMENT ---
function openDataModal() { document.getElementById('dataModal').style.display = 'block'; updateYears('addCourse', 'addYear'); }
function closeDataModal() { document.getElementById('dataModal').style.display = 'none'; }

function saveOneStudent() {
    const c = document.getElementById('addCourse').value;
    const y = document.getElementById('addYear').value;
    const r = document.getElementById('newRoll').value;
    const n = document.getElementById('newName').value;
    if(!r || !n) return;
    saveDB(c, y, r, n);
    document.getElementById('newRoll').value = '';
    document.getElementById('newName').value = '';
    alert("Student Saved!");
}

function importBulk() {
    const c = document.getElementById('addCourse').value;
    const y = document.getElementById('addYear').value;
    const text = document.getElementById('bulkInput').value;
    if(!text) return;
    text.split('\n').forEach(line => {
        const p = line.split(',');
        if(p.length >= 2) saveDB(c, y, p[0].trim(), p[1].trim());
    });
    alert("Import Successful");
}

function saveDB(c, y, roll, name) {
    const key = `STUD_${c}_${y}`;
    let arr = JSON.parse(localStorage.getItem(key)) || [];
    arr.push({ roll, name });
    localStorage.setItem(key, JSON.stringify(arr));
}

// --- NEW CLEAR BATCH FUNCTION ---
function clearBatchDB() {
    const c = document.getElementById('addCourse').value;
    const y = document.getElementById('addYear').value;
    if(!c || !y) { alert("Select Course and Year first"); return; }
    if(confirm(`Are you sure you want to DELETE ALL students in ${c} - Year ${y}?\nThis cannot be undone.`)) {
        const key = `STUD_${c}_${y}`;
        localStorage.removeItem(key);
        alert("Student list cleared.");
    }
}